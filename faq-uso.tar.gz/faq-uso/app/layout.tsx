import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "FAQ — Unidades de Atención USO",
  description: "Registro de preguntas frecuentes de las unidades de atención al estudiante",
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="es">
      <body>{children}</body>
    </html>
  );
}
