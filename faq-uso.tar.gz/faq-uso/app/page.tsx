import FormFAQ from "@/components/FormFAQ";

export default function Home() {
  return (
    <main className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-xl mx-auto">
        {/* Header */}
        <div className="bg-blue-800 text-white rounded-t-2xl px-8 py-7">
          <h1 className="text-lg font-semibold mb-1">
            Preguntas Frecuentes — Unidades de Atención USO
          </h1>
          <p className="text-sm opacity-80 leading-relaxed">
            Registra las consultas más frecuentes de tu área para construir
            la base de conocimientos institucional.
          </p>
        </div>
        {/* Form card */}
        <div className="bg-white border border-gray-200 border-t-0 rounded-b-2xl px-8 py-8">
          <FormFAQ />
        </div>
      </div>
    </main>
  );
}
