import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

export async function POST(req: NextRequest) {
  try {
    const form = await req.formData();
    const file = form.get("file") as File;
    const respuestaId = form.get("respuesta_id") as string;
    const indicaciones = (form.get("indicaciones") as string) || null;

    if (!file || !respuestaId) {
      return NextResponse.json({ error: "Faltan datos" }, { status: 400 });
    }

    if (file.size > 10 * 1024 * 1024) {
      return NextResponse.json({ error: "El archivo supera 10 MB" }, { status: 400 });
    }

    const slug = file.name.replace(/[^a-zA-Z0-9._-]/g, "_");
    const path = `${respuestaId}/${Date.now()}_${slug}`;

    const buffer = Buffer.from(await file.arrayBuffer());

    const { error: uploadErr } = await supabaseAdmin.storage
      .from("faq-documentos")
      .upload(path, buffer, {
        contentType: file.type || "application/octet-stream",
        upsert: false,
      });

    if (uploadErr) throw uploadErr;

    // Save document record
    const { error: dbErr } = await supabaseAdmin.from("faq_documentos").insert({
      respuesta_id: respuestaId,
      nombre_archivo: file.name,
      storage_path: path,
      indicaciones,
    });

    if (dbErr) throw dbErr;

    return NextResponse.json({ ok: true, path });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : String(e);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
