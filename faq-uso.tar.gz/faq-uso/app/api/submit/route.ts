import { NextRequest, NextResponse } from "next/server";
import { supabaseAdmin } from "@/lib/supabase";

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { nombre, correo, unidad, cargo, cargo_otro, modo, preguntas } = body;

    if (!nombre || !correo || !unidad || !cargo || !modo) {
      return NextResponse.json({ error: "Campos requeridos faltantes" }, { status: 400 });
    }

    // 1. Insert respondente
    const { data: resp, error: errResp } = await supabaseAdmin
      .from("faq_respuestas")
      .insert({ nombre, correo, unidad, cargo, cargo_otro: cargo_otro || null, modo })
      .select()
      .single();

    if (errResp) throw errResp;

    // 2. Insert preguntas (modo manual)
    if (modo === "manual" && preguntas?.length) {
      const rows = preguntas.map((p: { pregunta: string; respuesta: string; categoria: string }, i: number) => ({
        respuesta_id: resp.id,
        numero: i + 1,
        pregunta: p.pregunta,
        respuesta: p.respuesta,
        categoria: p.categoria || "Sin categoría",
      }));
      const { error: errPreg } = await supabaseAdmin.from("faq_preguntas").insert(rows);
      if (errPreg) throw errPreg;
    }

    return NextResponse.json({ ok: true, id: resp.id });
  } catch (e: unknown) {
    const message = e instanceof Error ? e.message : String(e);
    return NextResponse.json({ error: message }, { status: 500 });
  }
}
